63 set images renamed to match the project JSON keys. Original WebP bytes preserved.

artifacts/: set icons
extras/: two general UI icons and Initiate_Flower (not mapped to a current set)
set-images.json: set key to relative image path
rename-map.json: original names, new names, and SHA-256 hashes

Piece-to-set names checked against https://github.com/theBowja/genshin-db/tree/main/src/data/English/artifacts
